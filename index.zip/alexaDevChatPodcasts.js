var alexaDevChatPodcasts = [
  {
    "episode": 1,
    "audioURL": "https://p.scdn.co/mp3-preview/5c4fca39cd964267d37164312c9c6baae0bcc117?cid=null",
  },
  {
    "episode": 2,
    "audioURL": "https://p.scdn.co/mp3-preview/2b39f877d26df99740e2fd49b29e41d9001d29c1?cid=null",
  },
  {
    "episode": 3,
    "audioURL": "https://p.scdn.co/mp3-preview/ab731e85f55caa38a697c1e825728df2f78e5c85?cid=null",
  },
  {
    "episode": 4,
    "audioURL": "https://p.scdn.co/mp3-preview/8dcbe2702477ac98c7c711cbafcac43e10063949?cid=null",
  },
  {
    "episode": 5,
    "audioURL": "https://p.scdn.co/mp3-preview/4cfd0ab2b770e37313275d37788f687992b0ee17?cid=null",
  },
  {
    "episode": 6,
    "audioURL": "https://p.scdn.co/mp3-preview/2aef58727efcc1ae26122988259e96a7e6be397d?cid=null",
  },
  {
    "episode": 7,
    "audioURL": "https://p.scdn.co/mp3-preview/a62c076b4f89c98a19c2f2d094df022128d340b9?cid=null",
  },
  {
    "episode": 8,
    "audioURL": "https://p.scdn.co/mp3-preview/b914e6ccc07d8166ac6bd2cf09c7e960e5f6785d?cid=null",
  },
  {
    "episode": 9,
    "audioURL": "https://p.scdn.co/mp3-preview/0bd40c4c5f27548fd83f721380b99466c1c2094f?cid=null",
  },
  {
    "episode": 10,
    "audioURL": "https://p.scdn.co/mp3-preview/90dbf17146e76483a9fe296d7f03001e2f07199f?cid=null",
  }
];

module.exports = alexaDevChatPodcasts;
